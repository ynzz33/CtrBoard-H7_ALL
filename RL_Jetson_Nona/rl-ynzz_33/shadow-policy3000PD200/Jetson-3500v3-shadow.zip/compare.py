import argparse
import math
import struct
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--atol", type=float, default=1e-4)
parser.add_argument("--rtol", type=float, default=1e-4)
args = parser.parse_args()
if not all(math.isfinite(v) and v >= 0 for v in (args.atol, args.rtol)):
    parser.error("tolerances must be finite and nonnegative")
reference = Path("vectors/onnxruntime-actions.f32").read_bytes()
actual = Path("trt-actions.f32").read_bytes()
if not reference or len(reference) % 24 or len(actual) != len(reference):
    parser.exit(1, "Action file size mismatch\n")
expected = [v[0] for v in struct.iter_unpack("<f", reference)]
observed = [v[0] for v in struct.iter_unpack("<f", actual)]
if not all(map(math.isfinite, expected + observed)):
    parser.exit(1, "Nonfinite action\n")
errors = [abs(a - b) for a, b in zip(observed, expected)]
worst = max(range(len(errors)), key=errors.__getitem__)
failed = sum(e > args.atol + args.rtol * abs(b) for e, b in zip(errors, expected))
print(f"vectors={len(errors)//6} failed_components={failed} "
      f"max_abs_error={errors[worst]:.8g} row={worst//6} action={worst%6}")
raise SystemExit(int(failed != 0))
