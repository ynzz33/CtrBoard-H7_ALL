# policy3500v3 TensorRT offline check
Unpack into a separate directory on Jetson. From that directory:
 
    cmake -S deployment/jetson_rl -B build -DCMAKE_BUILD_TYPE=Release
    cmake --build build -j2
    ./build/jetson_rl convert --onnx models/policy3500v3.onnx --engine policy3500v3.engine
    ./build/jetson_rl vectors --engine policy3500v3.engine --input vectors/inputs.f32 --output trt-actions.f32
    python3 compare.py

The vectors exercise only the forward pass. Keep the existing 17679 installation for recording. The engine metadata uses the inherited protocol field for file validation; it does not identify a tested 3500v3 control interface.

compare.py uses preliminary atol=1e-4 and rtol=1e-4 and exits nonzero on a mismatch. Row and action indices are zero-based. This is an offline screening tolerance, pending CubeAI comparison.
