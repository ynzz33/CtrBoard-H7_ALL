#pragma once
namespace jrl {
inline constexpr const char* checkpoint_sha="unverified";
inline constexpr const char* onnx_sha="87f3fd5223de40b82c5d5a1f378b753339cdec720bdf2c4eb3d182810afbf78e";
}
